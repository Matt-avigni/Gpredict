/*
 * Copyright (C) 2024-2026 Matteo Avigni
 *
 * This file is part of Gpredict and distributed under the
 * GNU General Public License version 2 or later.
 */

#include "rigctld_client.h"

#include <errno.h>
#include <stdarg.h>
#include <string.h>

#include "rotctld-parse.h"
#include "sat-log.h"

#define RIGCTLD_PROBE_RETRY_DELAY_MS 50
#define RIGCTLD_REPLY_IDLE_TIMEOUT_MS 150
#define RIGCTLD_REPLY_RECOVERY_DRAIN_MS 200
#define RIGCTLD_VFO_TOKEN_MAX 64
#define RIGCTLD_MAIN_SUB_FRAGILE_SELECT_ATTEMPTS 1
#define RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US 350000
#define RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS 1
#define RIGCTLD_MIN_VALID_FREQ_HZ 100
#define RIGCTLD_MAX_VALID_FREQ_HZ G_GINT64_CONSTANT(1000000000000)

static gint rig_log_level = RIG_LOG_QUIET;

struct _RigctldClient {
    HamlibTransport       *transport;
    GRecMutex              meta_lock;
    rigctld_client_state_t state;
    gchar                 *state_reason;
    gchar                 *label;
    RigctldClientLogFunc   log_cb;
    gpointer               log_cb_data;
    gint64                 last_probe_us;
    vfo_t                  last_selected_vfo;
    RigCaps                caps;
};

static GRecMutex *rigctld_client_meta_lock(const RigctldClient *client)
{
    return (GRecMutex *)&client->meta_lock;
}

typedef struct {
    const gchar *match;
    guint        quirks;
} RigQuirkEntry;

static const RigQuirkEntry rig_quirks[] = {
    { "ic-9700", RIG_QUIRK_FORCE_MAIN_SUB },
    { "3081", RIG_QUIRK_FORCE_MAIN_SUB },
    { NULL, 0 }
};

static const gchar *rigctld_client_state_name(rigctld_client_state_t state)
{
    switch (state)
    {
    case RIGCTLD_CLIENT_STOPPED:
        return "STOPPED";
    case RIGCTLD_CLIENT_CONNECTING:
        return "CONNECTING";
    case RIGCTLD_CLIENT_PROBING:
        return "PROBING";
    case RIGCTLD_CLIENT_READY:
        return "READY";
    case RIGCTLD_CLIENT_DEGRADED:
        return "DEGRADED";
    default:
        return "UNKNOWN";
    }
}

void rigctld_client_set_log_level(rig_log_level_t level)
{
    if (level < RIG_LOG_QUIET)
        level = RIG_LOG_QUIET;
    if (level > RIG_LOG_TRACE)
        level = RIG_LOG_TRACE;

    g_atomic_int_set(&rig_log_level, (gint)level);
}

rig_log_level_t rigctld_client_get_log_level(void)
{
    return (rig_log_level_t)g_atomic_int_get(&rig_log_level);
}

void rigctld_client_set_log_callback(RigctldClient *client,
                                     RigctldClientLogFunc cb,
                                     gpointer user_data)
{
    if (client == NULL)
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    client->log_cb = cb;
    client->log_cb_data = user_data;
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
}

static gchar *rigctld_client_dup_trimmed(const gchar *text)
{
    gchar *copy = NULL;

    if (text == NULL)
        return g_strdup("");

    copy = g_strdup(text);
    g_strchomp(copy);
    g_strstrip(copy);
    return copy;
}

static gboolean rigctld_client_frequency_usable(gint64 freq_hz)
{
    return freq_hz >= RIGCTLD_MIN_VALID_FREQ_HZ &&
        freq_hz <= RIGCTLD_MAX_VALID_FREQ_HZ;
}

static void rigctld_client_forensic_line(RigctldClient *client,
                                         const gchar *prefix,
                                         const gchar *line)
{
    gchar *label = NULL;
    gchar *msg = NULL;

    if (client == NULL || prefix == NULL || line == NULL || *line == '\0')
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    label = g_strdup(client->label ? client->label : "rig");
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));

    msg = g_strdup_printf("[%s] %s", label ? label : "rig", line);
    sat_log_forensic(g_str_has_suffix(prefix, ":err") ?
                     SAT_LOG_LEVEL_ERROR : SAT_LOG_LEVEL_INFO,
                     "%s: %s", prefix, msg);
    g_free(msg);
    g_free(label);
}

static void rigctld_client_forensic_lines(RigctldClient *client,
                                          const gchar *prefix,
                                          const gchar *text)
{
    gchar **lines = NULL;

    if (client == NULL || prefix == NULL || text == NULL || *text == '\0')
        return;

    lines = g_strsplit(text, "\n", -1);
    for (gint i = 0; lines[i] != NULL; i++)
    {
        gchar *trimmed = g_strdup(lines[i]);

        g_strstrip(trimmed);
        if (*trimmed != '\0')
            rigctld_client_forensic_line(client, prefix, trimmed);
        g_free(trimmed);
    }
    g_strfreev(lines);
}

static void rigctld_client_emit_log_line(RigctldClient *client,
                                         const gchar *prefix,
                                         const gchar *line)
{
    RigctldClientLogFunc cb = NULL;
    gpointer user_data = NULL;
    gchar *label = NULL;
    gchar *msg = NULL;

    if (client == NULL || prefix == NULL || line == NULL || *line == '\0')
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    cb = client->log_cb;
    user_data = client->log_cb_data;
    label = g_strdup(client->label ? client->label : "rig");
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));

    if (cb == NULL)
    {
        g_free(label);
        return;
    }

    msg = g_strdup_printf("[%s] %s", label ? label : "rig", line);
    cb(client, prefix, msg, user_data);
    g_free(msg);
    g_free(label);
}

static void rigctld_client_emit_log_lines(RigctldClient *client,
                                          const gchar *prefix,
                                          const gchar *text)
{
    gchar **lines = NULL;

    if (client == NULL || prefix == NULL || text == NULL || *text == '\0')
        return;

    lines = g_strsplit(text, "\n", -1);
    for (gint i = 0; lines[i] != NULL; i++)
    {
        gchar *trimmed = g_strdup(lines[i]);

        g_strstrip(trimmed);
        if (*trimmed != '\0')
            rigctld_client_emit_log_line(client, prefix, trimmed);
        g_free(trimmed);
    }
    g_strfreev(lines);
}

static void rigctld_client_emit_logf(RigctldClient *client,
                                     const gchar *prefix,
                                     const gchar *fmt,
                                     ...)
    G_GNUC_PRINTF(3, 4);

static void rigctld_client_emit_logf(RigctldClient *client,
                                     const gchar *prefix,
                                     const gchar *fmt,
                                     ...)
{
    va_list args;
    gchar *msg = NULL;

    if (client == NULL || prefix == NULL || fmt == NULL)
        return;

    va_start(args, fmt);
    msg = g_strdup_vprintf(fmt, args);
    va_end(args);

    if (msg == NULL)
        return;

    rigctld_client_emit_log_lines(client, prefix, msg);
    g_free(msg);
}

static void rigctld_client_set_state(RigctldClient *client,
                                     rigctld_client_state_t state,
                                     const gchar *fmt,
                                     ...) G_GNUC_PRINTF(3, 4);
static gboolean rigctld_client_request(RigctldClient *client,
                                       const gchar *cmd,
                                       hamlib_read_mode_t mode,
                                       hamlib_term_t term,
                                       gint timeout_ms,
                                       gint idle_timeout_ms,
                                       gint retries,
                                       gint retry_delay_ms,
                                       gchar *reply,
                                       gsize reply_len,
                                       HamlibResponseInfo *info,
                                       gboolean wire_log);

static void rigctld_client_caps_clear(RigCaps *caps)
{
    if (caps == NULL)
        return;

    g_free(caps->signature);
    g_free(caps->backend_version);
    g_free(caps->default_vfo_token);
    g_free(caps->vfo_token_main);
    g_free(caps->vfo_token_sub);
    caps->signature = NULL;
    caps->backend_version = NULL;
    caps->default_vfo_token = NULL;
    caps->vfo_token_main = NULL;
    caps->vfo_token_sub = NULL;

    if (caps->vfo_candidates)
        g_ptr_array_set_size(caps->vfo_candidates, 0);
    if (caps->vfo_working)
        g_hash_table_remove_all(caps->vfo_working);

    caps->rig_model = 0;
    caps->has_get_freq = FALSE;
    caps->has_set_freq = FALSE;
    caps->has_tokenized_get_freq = FALSE;
    caps->has_tokenized_set_freq = FALSE;
    caps->has_get_vfo = FALSE;
    caps->has_set_vfo = FALSE;
    caps->has_set_vfo_opt = FALSE;
    caps->vfo_opt_enabled = FALSE;
    caps->vfo_opt_unsafe = FALSE;
    caps->prefer_main_sub_tokens = FALSE;
    caps->strategy = RIG_STRATEGY_PLAIN_FREQ;
    caps->quirks = RIG_QUIRK_NONE;
}

static void rigctld_client_caps_init(RigCaps *caps)
{
    if (caps == NULL)
        return;

    memset(caps, 0, sizeof(*caps));
    caps->vfo_candidates = g_ptr_array_new_with_free_func(g_free);
    caps->vfo_working = g_hash_table_new_full(g_str_hash, g_str_equal,
                                              g_free, NULL);
    caps->strategy = RIG_STRATEGY_PLAIN_FREQ;
}

static void rigctld_client_caps_release(RigCaps *caps)
{
    if (caps == NULL)
        return;

    rigctld_client_caps_clear(caps);
    if (caps->vfo_candidates)
        g_ptr_array_free(caps->vfo_candidates, TRUE);
    if (caps->vfo_working)
        g_hash_table_destroy(caps->vfo_working);
    caps->vfo_candidates = NULL;
    caps->vfo_working = NULL;
}

static void rigctld_client_caps_copy_snapshot(const RigCaps *src,
                                              RigCaps *dst)
{
    if (dst == NULL)
        return;

    rigctld_client_caps_init(dst);
    if (src == NULL)
        return;

    dst->signature = g_strdup(src->signature);
    dst->backend_version = g_strdup(src->backend_version);
    dst->rig_model = src->rig_model;
    dst->has_get_freq = src->has_get_freq;
    dst->has_set_freq = src->has_set_freq;
    dst->has_tokenized_get_freq = src->has_tokenized_get_freq;
    dst->has_tokenized_set_freq = src->has_tokenized_set_freq;
    dst->has_get_vfo = src->has_get_vfo;
    dst->has_set_vfo = src->has_set_vfo;
    dst->has_set_vfo_opt = src->has_set_vfo_opt;
    dst->vfo_opt_enabled = src->vfo_opt_enabled;
    dst->vfo_opt_unsafe = src->vfo_opt_unsafe;
    dst->prefer_main_sub_tokens = src->prefer_main_sub_tokens;
    dst->strategy = src->strategy;
    dst->default_vfo_token = g_strdup(src->default_vfo_token);
    dst->vfo_token_main = g_strdup(src->vfo_token_main);
    dst->vfo_token_sub = g_strdup(src->vfo_token_sub);
    dst->quirks = src->quirks;

    if (src->vfo_candidates != NULL)
    {
        for (guint i = 0; i < src->vfo_candidates->len; i++)
        {
            const gchar *token = g_ptr_array_index(src->vfo_candidates, i);

            if (token != NULL)
                g_ptr_array_add(dst->vfo_candidates, g_strdup(token));
        }
    }

    if (src->vfo_working != NULL)
    {
        GHashTableIter iter;
        gpointer key = NULL;
        gpointer value = NULL;

        g_hash_table_iter_init(&iter, src->vfo_working);
        while (g_hash_table_iter_next(&iter, &key, &value))
        {
            const gchar *token = key;

            if (token != NULL)
                g_hash_table_replace(dst->vfo_working, g_strdup(token), value);
        }
    }
}

static void rigctld_client_apply_quirks(RigCaps *caps)
{
    gchar *sig = NULL;

    if (caps == NULL || caps->signature == NULL)
        return;

    sig = g_ascii_strdown(caps->signature, -1);
    for (gint i = 0; rig_quirks[i].match != NULL; i++)
    {
        if (g_strrstr(sig, rig_quirks[i].match) != NULL)
            caps->quirks |= rig_quirks[i].quirks;
    }
    g_free(sig);
}

static void rigctld_client_extract_first_lines(const gchar *text,
                                               gchar **line1_out,
                                               gchar **line2_out)
{
    gchar *line1 = NULL;
    gchar *line2 = NULL;

    if (line1_out)
        *line1_out = NULL;
    if (line2_out)
        *line2_out = NULL;

    if (text == NULL || *text == '\0')
        return;

    gchar **lines = g_strsplit(text, "\n", -1);
    for (gint i = 0; lines[i] != NULL; i++)
    {
        gchar *line = g_strstrip(lines[i]);

        if (line[0] == '\0')
            continue;

        if (line1 == NULL)
        {
            line1 = g_strdup(line);
            continue;
        }
        if (line2 == NULL)
        {
            line2 = g_strdup(line);
            break;
        }
    }
    g_strfreev(lines);

    if (line1_out)
        *line1_out = line1;
    else
        g_free(line1);

    if (line2_out)
        *line2_out = line2;
    else
        g_free(line2);
}

static gboolean rigctld_dump_state_line1_ok(const gchar *text)
{
    gchar *line1 = NULL;
    gboolean ok = FALSE;

    if (text == NULL || *text == '\0')
        return FALSE;

    rigctld_client_extract_first_lines(text, &line1, NULL);
    if (line1 != NULL && g_str_has_prefix(line1, "1"))
        ok = TRUE;
    g_free(line1);

    return ok;
}

static gchar *rigctld_client_build_signature(const gchar *text,
                                             gint rig_model,
                                             const gchar *backend_version)
{
    gchar *line1 = NULL;
    gchar *line2 = NULL;
    gchar *signature = NULL;

    rigctld_client_extract_first_lines(text, &line1, &line2);
    signature = g_strdup_printf("model=%d line1=%s line2=%s backend=%s",
                                rig_model,
                                line1 ? line1 : "(none)",
                                line2 ? line2 : "(none)",
                                backend_version ? backend_version : "(none)");
    g_free(line1);
    g_free(line2);
    return signature;
}

static gboolean rigctld_client_parse_frequency(const gchar *text,
                                               gint64 *freq_out)
{
    const gchar *p = text;
    gchar *endptr = NULL;
    gint64 value = 0;

    if (freq_out)
        *freq_out = 0;

    if (text == NULL || *text == '\0')
        return FALSE;

    while (*p != '\0')
    {
        if (g_ascii_isdigit(*p) || *p == '-' || *p == '+')
        {
            value = g_ascii_strtoll(p, &endptr, 10);
            if (endptr != p)
            {
                if (freq_out)
                    *freq_out = value;
                return TRUE;
            }
        }
        p++;
    }

    return FALSE;
}

static gboolean rigctld_client_parse_vfo_reply(const gchar *text,
                                               gchar *token_out,
                                               gsize token_len)
{
    gchar **lines = NULL;
    gboolean ok = FALSE;

    if (token_out != NULL && token_len > 0)
        token_out[0] = '\0';

    if (text == NULL || *text == '\0' || token_out == NULL || token_len == 0)
        return FALSE;

    lines = g_strsplit(text, "\n", -1);
    for (gint i = 0; lines[i] != NULL; i++)
    {
        gchar *line = g_strstrip(lines[i]);

        if (line[0] == '\0')
            continue;

        g_strlcpy(token_out, line, token_len);
        ok = TRUE;
        break;
    }

    g_strfreev(lines);
    return ok;
}

static vfo_t rigctld_client_classify_vfo_token(const gchar *token)
{
    static const gchar *main_tokens[] =
        { "VFOA", "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_tokens[] =
        { "VFOB", "Sub", "SubA", "VFO_SUB", "TX", NULL };

    if (token == NULL || *token == '\0')
        return VFO_NONE;

    for (gint i = 0; main_tokens[i] != NULL; i++)
    {
        if (g_ascii_strcasecmp(token, main_tokens[i]) == 0)
            return VFO_MAIN;
    }

    for (gint i = 0; sub_tokens[i] != NULL; i++)
    {
        if (g_ascii_strcasecmp(token, sub_tokens[i]) == 0)
            return VFO_SUB;
    }

    return VFO_NONE;
}

static gint rigctld_client_expected_model(const radio_conf_t *conf)
{
    gint model = 0;

    if (conf == NULL)
        return 0;

    model = conf->rigctld_model;
    if (model <= 0)
        model = radio_model_to_hamlib_model(conf->radio_model);

    return model;
}

static void rigctld_client_add_vfo_candidate(RigCaps *caps,
                                             const gchar *token)
{
    gchar *trimmed = NULL;

    if (caps == NULL || token == NULL || *token == '\0')
        return;

    trimmed = g_strdup(token);
    g_strstrip(trimmed);
    if (*trimmed == '\0')
    {
        g_free(trimmed);
        return;
    }

    for (guint i = 0; i < caps->vfo_candidates->len; i++)
    {
        const gchar *existing = g_ptr_array_index(caps->vfo_candidates, i);
        if (g_strcmp0(existing, trimmed) == 0)
        {
            g_free(trimmed);
            return;
        }
    }

    g_ptr_array_add(caps->vfo_candidates, trimmed);
}

static void rigctld_client_parse_vfo_list(RigCaps *caps, const gchar *line)
{
    const gchar *sep = NULL;
    gchar *list = NULL;
    gchar **parts = NULL;

    if (caps == NULL || line == NULL)
        return;

    sep = strchr(line, '=');
    if (sep == NULL)
        sep = strchr(line, ':');
    if (sep == NULL || *(sep + 1) == '\0')
        return;

    list = g_strdup(sep + 1);
    g_strstrip(list);
    parts = g_strsplit_set(list, " \t,", -1);
    for (gint i = 0; parts[i] != NULL; i++)
    {
        if (parts[i][0] == '\0')
            continue;
        rigctld_client_add_vfo_candidate(caps, parts[i]);
    }

    g_strfreev(parts);
    g_free(list);
}

static void rigctld_client_parse_dump_state(RigCaps *caps, const gchar *text)
{
    gchar **lines = NULL;

    if (caps == NULL || text == NULL || *text == '\0')
        return;

    (void) parse_dump_state_model_id(text, &caps->rig_model);

    lines = g_strsplit(text, "\n", -1);
    for (gint i = 0; lines[i] != NULL; i++)
    {
        gchar *line = g_strstrip(lines[i]);
        gchar *lower = NULL;

        if (line[0] == '\0')
            continue;

        lower = g_ascii_strdown(line, -1);
        if (g_str_has_prefix(lower, "has_get_vfo"))
            caps->has_get_vfo = g_strrstr(lower, "1") != NULL;
        if (g_str_has_prefix(lower, "has_set_vfo"))
            caps->has_set_vfo = g_strrstr(lower, "1") != NULL;
        if (g_str_has_prefix(lower, "has_set_vfo_opt"))
            caps->has_set_vfo_opt = g_strrstr(lower, "1") != NULL;

        if (g_strrstr(lower, "vfo list") != NULL ||
            g_strrstr(lower, "vfo_list") != NULL)
            rigctld_client_parse_vfo_list(caps, line);

        if (caps->backend_version == NULL &&
            (g_strrstr(lower, "hamlib") != NULL ||
             g_strrstr(lower, "rigctld") != NULL ||
             g_strrstr(lower, "backend") != NULL))
        {
            caps->backend_version = g_strdup(line);
        }

        g_free(lower);
    }
    g_strfreev(lines);
}

static gboolean rigctld_client_parse_int_reply(const gchar *reply,
                                               gint64 *value_out)
{
    gchar **lines = NULL;
    gchar *trimmed = NULL;
    gchar *endptr = NULL;
    gint64 value = 0;
    gboolean ok = FALSE;

    if (value_out != NULL)
        *value_out = 0;

    if (reply == NULL || *reply == '\0')
        return FALSE;

    lines = g_strsplit(reply, "\n", 2);
    if (lines == NULL || lines[0] == NULL)
        goto done;

    trimmed = g_strstrip(lines[0]);
    if (trimmed == NULL || *trimmed == '\0')
        goto done;

    value = g_ascii_strtoll(trimmed, &endptr, 10);
    if (endptr == trimmed)
        goto done;

    if (value_out != NULL)
        *value_out = value;
    ok = TRUE;

done:
    g_strfreev(lines);
    return ok;
}

static gboolean rigctld_client_try_chk_vfo(RigctldClient *client,
                                           gboolean *enabled_out,
                                           gint timeout_ms,
                                           gboolean wire_log)
{
    gchar reply[128];
    HamlibResponseInfo info = { 0 };
    gint64 status = 0;
    gboolean ok = FALSE;

    if (enabled_out != NULL)
        *enabled_out = FALSE;

    if (client == NULL)
        return FALSE;

    reply[0] = '\0';
    ok = rigctld_client_request(client,
                                "\\chk_vfo\n",
                                HAMLIB_READ_MULTILINE_RPRT,
                                HAMLIB_TERM_RPRT,
                                timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                reply, sizeof(reply),
                                &info,
                                wire_log);
    if (!ok || (info.saw_rprt && info.rprt_code != 0))
        return FALSE;

    if (!rigctld_client_parse_int_reply(reply, &status))
        return FALSE;

    if (enabled_out != NULL)
        *enabled_out = (status != 0);

    return TRUE;
}

static gboolean rigctld_client_try_get_freq(RigctldClient *client,
                                            const gchar *cmd,
                                            gint64 *freq_out,
                                            gchar *reply,
                                            gsize reply_len,
                                            gint timeout_ms,
                                            gboolean wire_log)
{
    HamlibResponseInfo info = { 0 };
    gboolean ok = FALSE;
    gboolean parsed = FALSE;
    gint64 freq = 0;

    if (freq_out)
        *freq_out = 0;
    if (reply && reply_len > 0)
        reply[0] = '\0';

    ok = rigctld_client_request(client, cmd,
                                HAMLIB_READ_MULTILINE_RPRT,
                                HAMLIB_TERM_RPRT,
                                timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                reply, reply_len,
                                &info,
                                wire_log);
    if (!ok)
        return FALSE;

    if (info.saw_rprt && info.rprt_code != 0)
        return FALSE;

    parsed = rigctld_client_parse_frequency(reply, &freq);
    if (!parsed && wire_log)
    {
        gchar *trim_reply = rigctld_client_dup_trimmed(reply);

        rigctld_client_emit_logf(client, "gpredict:err",
                                 "frequency parse failed reply=%s",
                                 (trim_reply && *trim_reply) ? trim_reply : "(empty)");
        g_free(trim_reply);
    }

    if (!parsed)
        return FALSE;

    if (!rigctld_client_frequency_usable(freq))
    {
        if (wire_log)
        {
            gchar *trim_reply = rigctld_client_dup_trimmed(reply);

            rigctld_client_emit_logf(client, "gpredict:err",
                                     "frequency reply unusable value=%" G_GINT64_FORMAT
                                     " reply=%s",
                                     freq,
                                     (trim_reply && *trim_reply) ? trim_reply : "(empty)");
            g_free(trim_reply);
        }
        return FALSE;
    }

    if (freq_out)
        *freq_out = freq;

    if (!info.saw_rprt && wire_log)
    {
        gchar *trim_cmd = rigctld_client_dup_trimmed(cmd);

        sat_log_forensic(SAT_LOG_LEVEL_INFO,
                         "gpredict:rx: [%s] accepted frequency reply without RPRT cmd=%s",
                         client->label ? client->label : "rig",
                         (trim_cmd && *trim_cmd) ? trim_cmd : "(empty)");
        g_free(trim_cmd);
    }

    return TRUE;
}

static gboolean rigctld_client_try_get_freq_retry(RigctldClient *client,
                                                  const gchar *cmd,
                                                  gint64 *freq_out,
                                                  gchar *reply,
                                                  gsize reply_len,
                                                  gint timeout_ms,
                                                  gint retries,
                                                  gboolean wire_log)
{
    gint attempt = 0;

    for (attempt = 0; attempt <= retries; attempt++)
    {
        if (rigctld_client_try_get_freq(client, cmd, freq_out,
                                        reply, reply_len, timeout_ms,
                                        wire_log))
            return TRUE;

        (void)hamlib_transport_drain(client->transport,
                                     RIGCTLD_REPLY_RECOVERY_DRAIN_MS, NULL);
        if (attempt < retries)
        {
            if (wire_log)
                rigctld_client_emit_logf(client, "gpredict",
                                         "retrying cmd=%s attempt=%d/%d",
                                         cmd,
                                         attempt + 2,
                                         retries + 1);
            g_usleep((gulong)RIGCTLD_PROBE_RETRY_DELAY_MS * 1000);
        }
    }

    return FALSE;
}

static gboolean rigctld_client_try_set_ok(RigctldClient *client,
                                          const gchar *cmd,
                                          gchar *reply,
                                          gsize reply_len,
                                          gint timeout_ms,
                                          gboolean wire_log)
{
    HamlibResponseInfo info = { 0 };
    gboolean ok = FALSE;

    if (reply && reply_len > 0)
        reply[0] = '\0';

    ok = rigctld_client_request(client, cmd,
                                HAMLIB_READ_MULTILINE_RPRT,
                                HAMLIB_TERM_RPRT,
                                timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                reply, reply_len,
                                &info,
                                wire_log);
    if (!ok)
        return FALSE;

    if (!info.saw_rprt)
        return FALSE;

    if (info.rprt_code != 0)
        return FALSE;

    return TRUE;
}

static gboolean rigctld_client_try_select_vfo(RigctldClient *client,
                                              const gchar *token,
                                              gint timeout_ms,
                                              gboolean wire_log)
{
    gchar cmd[RIGCTLD_VFO_TOKEN_MAX];
    gchar reply[128];

    if (token == NULL || *token == '\0')
        return FALSE;

    g_snprintf(cmd, sizeof(cmd), "V %s\x0a", token);
    return rigctld_client_try_set_ok(client, cmd, reply, sizeof(reply),
                                     timeout_ms, wire_log);
}

static gboolean rigctld_client_caps_fragile_main_sub(const RigCaps *caps)
{
    return caps != NULL &&
        caps->prefer_main_sub_tokens &&
        (caps->quirks & RIG_QUIRK_FORCE_MAIN_SUB) != 0;
}

static gboolean rigctld_client_try_select_vfo_retry(RigctldClient *client,
                                                    const gchar *token,
                                                    gint timeout_ms,
                                                    gint attempts,
                                                    gulong settle_us,
                                                    gboolean wire_log)
{
    gint max_attempts = (attempts > 0) ? attempts : 1;

    if (client == NULL || token == NULL || *token == '\0')
        return FALSE;

    for (gint attempt = 0; attempt < max_attempts; attempt++)
    {
        if (attempt > 0)
        {
            (void)hamlib_transport_drain(client->transport,
                                         RIGCTLD_REPLY_RECOVERY_DRAIN_MS, NULL);
            if (settle_us > 0)
                g_usleep(settle_us);
        }

        if (rigctld_client_try_select_vfo(client, token, timeout_ms, wire_log))
        {
            if (wire_log && max_attempts > 1)
                rigctld_client_emit_logf(client, "gpredict",
                                         "select VFO %s ok attempt=%d/%d",
                                         token, attempt + 1, max_attempts);
            return TRUE;
        }
    }

    if (wire_log)
        rigctld_client_emit_logf(client, "gpredict:err",
                                 "select VFO %s failed after %d attempt(s)",
                                 token, max_attempts);

    return FALSE;
}

static gboolean rigctld_client_try_get_vfo(RigctldClient *client,
                                           gchar *token_out,
                                           gsize token_len,
                                           gint timeout_ms,
                                           gboolean wire_log)
{
    HamlibResponseInfo info = { 0 };
    gchar reply[128];
    gboolean ok = FALSE;

    if (token_out != NULL && token_len > 0)
        token_out[0] = '\0';

    if (client == NULL || token_out == NULL || token_len == 0)
        return FALSE;

    ok = rigctld_client_request(client, "v\n",
                                HAMLIB_READ_MULTILINE_RPRT,
                                HAMLIB_TERM_RPRT,
                                timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                reply, sizeof(reply),
                                &info,
                                wire_log);
    if (!ok)
        return FALSE;

    if (!info.saw_rprt)
        return FALSE;

    if (info.rprt_code != 0)
        return FALSE;

    ok = rigctld_client_parse_vfo_reply(reply, token_out, token_len);
    if (!ok && wire_log)
    {
        gchar *trim_reply = rigctld_client_dup_trimmed(reply);

        rigctld_client_emit_logf(client, "gpredict:err",
                                 "VFO parse failed reply=%s",
                                 (trim_reply && *trim_reply) ? trim_reply : "(empty)");
        g_free(trim_reply);
    }

    return ok;
}

static gboolean rigctld_client_try_get_vfo_retry(RigctldClient *client,
                                                 gchar *token_out,
                                                 gsize token_len,
                                                 gint timeout_ms,
                                                 gint retries,
                                                 gboolean wire_log)
{
    gint attempt = 0;

    for (attempt = 0; attempt <= retries; attempt++)
    {
        if (rigctld_client_try_get_vfo(client, token_out, token_len,
                                       timeout_ms, wire_log))
            return TRUE;

        (void)hamlib_transport_drain(client->transport,
                                     RIGCTLD_REPLY_RECOVERY_DRAIN_MS, NULL);
        if (attempt < retries)
        {
            if (wire_log)
                rigctld_client_emit_logf(client, "gpredict",
                                         "retrying cmd=v attempt=%d/%d",
                                         attempt + 2,
                                         retries + 1);
            g_usleep((gulong)RIGCTLD_PROBE_RETRY_DELAY_MS * 1000);
        }
    }

    return FALSE;
}

static gboolean rigctld_client_probe_selected_vfo_readback(RigctldClient *client,
                                                           gint timeout_ms,
                                                           gboolean wire_log)
{
    gchar reply[128];
    gint64 freq = 0;

    if (client == NULL)
        return FALSE;

    if (!rigctld_client_try_get_freq_retry(client, "f\n",
                                           &freq, reply, sizeof(reply),
                                           timeout_ms, 0,
                                           wire_log))
    {
        return FALSE;
    }

    client->caps.has_get_freq = TRUE;
    return TRUE;
}

static gboolean rigctld_client_has_vfo_candidate(const RigCaps *caps,
                                                 const gchar *token);

static gboolean rigctld_client_probe_tokenized_freq_token(RigctldClient *client,
                                                          const gchar *token,
                                                          gint64 *reference_freq_hz,
                                                          gint timeout_ms,
                                                          gboolean wire_log)
{
    gchar cmd[96];
    gchar reply[256];
    HamlibResponseInfo info = { 0 };
    gint64 freq = 0;
    gboolean parsed = FALSE;
    gboolean ok = FALSE;

    if (client == NULL || token == NULL || *token == '\0')
        return FALSE;

    g_snprintf(cmd, sizeof(cmd), "f %s\x0a", token);
    ok = rigctld_client_request(client, cmd,
                                HAMLIB_READ_MULTILINE_RPRT,
                                HAMLIB_TERM_RPRT,
                                timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                reply, sizeof(reply),
                                &info,
                                wire_log);
    if (!ok || (info.saw_rprt && info.rprt_code != 0))
        return FALSE;

    parsed = rigctld_client_parse_frequency(reply, &freq);
    if (!parsed || !rigctld_client_frequency_usable(freq))
        return FALSE;

    client->caps.has_get_freq = TRUE;
    client->caps.has_tokenized_get_freq = TRUE;
    if (reference_freq_hz != NULL)
        *reference_freq_hz = freq;

    g_hash_table_replace(client->caps.vfo_working, g_strdup(token),
                         GINT_TO_POINTER(1));
    return TRUE;
}

static const gchar *rigctld_client_probe_tokenized_vfo_token(
    RigctldClient *client,
    const gchar * const *candidates,
    gboolean allow_unlisted,
    gint64 *reference_freq_hz,
    gint timeout_ms,
    gboolean wire_log)
{
    RigCaps *caps = NULL;

    if (client == NULL || candidates == NULL)
        return NULL;

    caps = &client->caps;
    for (gint i = 0; candidates[i] != NULL; i++)
    {
        const gchar *token = candidates[i];

        if (!allow_unlisted &&
            caps->vfo_candidates != NULL &&
            caps->vfo_candidates->len > 0 &&
            !rigctld_client_has_vfo_candidate(caps, token))
        {
            continue;
        }

        if (rigctld_client_probe_tokenized_freq_token(client, token,
                                                      reference_freq_hz,
                                                      timeout_ms, wire_log))
            return token;
    }

    return NULL;
}

static gboolean rigctld_client_probe_selected_vfo_matches(RigctldClient *client,
                                                          const gchar *token,
                                                          gint timeout_ms,
                                                          gboolean wire_log,
                                                          gboolean *available_out)
{
    gchar current[128];
    vfo_t expected_vfo = VFO_NONE;
    vfo_t current_vfo = VFO_NONE;

    if (available_out != NULL)
        *available_out = FALSE;

    if (client == NULL || token == NULL || *token == '\0')
        return FALSE;

    if (!rigctld_client_try_get_vfo_retry(client, current, sizeof(current),
                                          timeout_ms, 0, wire_log))
        return FALSE;

    if (available_out != NULL)
        *available_out = TRUE;
    client->caps.has_get_vfo = TRUE;
    if (g_ascii_strcasecmp(current, token) == 0)
        return TRUE;

    expected_vfo = rigctld_client_classify_vfo_token(token);
    current_vfo = rigctld_client_classify_vfo_token(current);

    return (expected_vfo != VFO_NONE && expected_vfo == current_vfo);
}

static const gchar *rigctld_client_find_vfo_token_in_table(vfo_t vfo,
                                                           GHashTable *table)
{
    static const gchar *main_candidates[] =
        { "VFOA", "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_candidates[] =
        { "VFOB", "Sub", "SubA", "VFO_SUB", "TX", NULL };
    const gchar * const *candidates = NULL;

    if (table == NULL)
        return NULL;

    if (vfo == VFO_MAIN)
        candidates = main_candidates;
    else if (vfo == VFO_SUB)
        candidates = sub_candidates;
    else
        return NULL;

    for (gint i = 0; candidates[i] != NULL; i++)
    {
        if (g_hash_table_contains(table, candidates[i]))
            return candidates[i];
    }

    return NULL;
}

static gboolean rigctld_client_has_vfo_candidate(const RigCaps *caps,
                                                 const gchar *token)
{
    if (caps == NULL || token == NULL || caps->vfo_candidates == NULL)
        return FALSE;

    for (guint i = 0; i < caps->vfo_candidates->len; i++)
    {
        const gchar *entry = g_ptr_array_index(caps->vfo_candidates, i);

        if (entry != NULL && g_ascii_strcasecmp(entry, token) == 0)
            return TRUE;
    }

    return FALSE;
}

static const gchar *rigctld_client_probe_select_token(RigctldClient *client,
                                                      const gchar * const *candidates,
                                                      GHashTable *vfo_selectable,
                                                      gint timeout_ms,
                                                      gint attempts,
                                                      gulong settle_us,
                                                      gboolean allow_unlisted,
                                                      gboolean require_validation,
                                                      gboolean wire_log)
{
    RigCaps *caps = NULL;

    if (client == NULL || candidates == NULL || vfo_selectable == NULL)
        return NULL;

    caps = &client->caps;

    for (gint i = 0; candidates[i] != NULL; i++)
    {
        const gchar *token = candidates[i];

        if (g_hash_table_contains(vfo_selectable, token))
            return token;

        if (!allow_unlisted &&
            caps->vfo_candidates != NULL &&
            caps->vfo_candidates->len > 0 &&
            !rigctld_client_has_vfo_candidate(caps, token))
        {
            continue;
        }

        if (!rigctld_client_try_select_vfo_retry(client, token,
                                                 timeout_ms,
                                                 attempts,
                                                 settle_us,
                                                 wire_log))
        {
            continue;
        }

        if (settle_us > 0)
            g_usleep(settle_us);

        if (require_validation)
        {
            gboolean validated = FALSE;
            gboolean vfo_readback_available = FALSE;

            validated = rigctld_client_probe_selected_vfo_matches(client,
                                                                  token,
                                                                  timeout_ms,
                                                                  wire_log,
                                                                  &vfo_readback_available);
            if (!validated && !vfo_readback_available)
                validated = rigctld_client_probe_selected_vfo_readback(client,
                                                                       timeout_ms,
                                                                       wire_log);
            if (!validated)
                continue;

            g_hash_table_replace(caps->vfo_working, g_strdup(token),
                                 GINT_TO_POINTER(1));
        }
        g_hash_table_replace(vfo_selectable, g_strdup(token),
                             GINT_TO_POINTER(1));
        return token;
    }

    return NULL;
}

static const gchar *rigctld_client_vfo_token(RigctldClient *client,
                                             vfo_t vfo)
{
    static const gchar *main_candidates_default[] =
        { "VFOA", "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_candidates_default[] =
        { "VFOB", "Sub", "SubA", "VFO_SUB", "TX", NULL };
    static const gchar *main_candidates_prefer[] =
        { "Main", "MainA", "VFO_MAIN", "RX", "VFOA", NULL };
    static const gchar *sub_candidates_prefer[] =
        { "Sub", "SubA", "VFO_SUB", "TX", "VFOB", NULL };
    static const gchar *main_candidates_strict[] =
        { "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_candidates_strict[] =
        { "Sub", "SubA", "VFO_SUB", "TX", NULL };
    const gchar *fallback = (vfo == VFO_SUB) ? "Sub" : "Main";
    const gchar * const *candidates = NULL;
    RigCaps *caps = NULL;

    if (client == NULL)
        return fallback;

    caps = &client->caps;

    if (vfo != VFO_MAIN && vfo != VFO_SUB)
        return fallback;

    if (vfo == VFO_MAIN && caps->vfo_token_main)
        return caps->vfo_token_main;
    if (vfo == VFO_SUB && caps->vfo_token_sub)
        return caps->vfo_token_sub;

    if (caps->strategy == RIG_STRATEGY_SELECT_VFO)
        candidates = (vfo == VFO_MAIN) ? main_candidates_default
                                       : sub_candidates_default;
    else if (caps->quirks & RIG_QUIRK_FORCE_MAIN_SUB)
        candidates = (vfo == VFO_MAIN) ? main_candidates_strict
                                       : sub_candidates_strict;
    else if (caps->prefer_main_sub_tokens)
        candidates = (vfo == VFO_MAIN) ? main_candidates_prefer
                                       : sub_candidates_prefer;
    else
        candidates = (vfo == VFO_MAIN) ? main_candidates_default
                                       : sub_candidates_default;

    for (gint i = 0; candidates[i] != NULL; i++)
    {
        if (g_hash_table_contains(caps->vfo_working, candidates[i]))
        {
            if (vfo == VFO_MAIN)
                caps->vfo_token_main = g_strdup(candidates[i]);
            else
                caps->vfo_token_sub = g_strdup(candidates[i]);
            return candidates[i];
        }
    }

    return fallback;
}

static void rigctld_client_set_state(RigctldClient *client,
                                     rigctld_client_state_t state,
                                     const gchar *fmt,
                                     ...)
{
    va_list args;
    gchar *reason = NULL;
    gchar *label = NULL;

    if (client == NULL)
        return;

    if (fmt != NULL)
    {
        va_start(args, fmt);
        reason = g_strdup_vprintf(fmt, args);
        va_end(args);
    }

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    label = g_strdup(client->label ? client->label : "rig");
    client->state = state;
    g_free(client->state_reason);
    client->state_reason = reason;
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));

    sat_log_forensic(SAT_LOG_LEVEL_INFO,
                     "rigctld client (%s) state=%s reason=%s",
                     label ? label : "rig",
                     rigctld_client_state_name(state),
                     reason ? reason : "(none)");
    g_free(label);
}

RigctldClient *rigctld_client_new(const gchar *label)
{
    RigctldClient *client = g_new0(RigctldClient, 1);

    client->transport = hamlib_transport_new();
    g_rec_mutex_init(&client->meta_lock);
    client->state = RIGCTLD_CLIENT_STOPPED;
    client->label = g_strdup(label ? label : "rig");
    client->last_selected_vfo = VFO_NONE;
    rigctld_client_caps_init(&client->caps);

    return client;
}

static gboolean rigctld_client_request(RigctldClient *client,
                                       const gchar *cmd,
                                       hamlib_read_mode_t mode,
                                       hamlib_term_t term,
                                       gint timeout_ms,
                                       gint idle_timeout_ms,
                                       gint retries,
                                       gint retry_delay_ms,
                                       gchar *reply,
                                       gsize reply_len,
                                       HamlibResponseInfo *info,
                                       gboolean wire_log)
{
    HamlibResponseInfo local = { 0 };
    gboolean ok = FALSE;
    gint err = 0;

    if (info)
        memset(info, 0, sizeof(*info));
    if (reply && reply_len > 0)
        reply[0] = '\0';

    if (client == NULL || client->transport == NULL || cmd == NULL)
        return FALSE;

    if (wire_log)
        rigctld_client_forensic_lines(client, "gpredict:tx", cmd);

    if (wire_log && rigctld_client_get_log_level() >= RIG_LOG_VERBOSE)
        rigctld_client_emit_log_lines(client, "gpredict:tx", cmd);

    ok = hamlib_transport_request(client->transport,
                                  cmd,
                                  mode,
                                  term,
                                  timeout_ms,
                                  idle_timeout_ms,
                                  retries,
                                  retry_delay_ms,
                                  reply, reply_len,
                                  &local);

    if (info)
        *info = local;

    if (!ok)
    {
        if (wire_log)
        {
            gchar *trim_cmd = rigctld_client_dup_trimmed(cmd);

            err = local.err ? local.err : EIO;
            sat_log_forensic(SAT_LOG_LEVEL_ERROR,
                             "gpredict:err: [%s] request failed cmd=%s err=%d (%s)",
                             client->label ? client->label : "rig",
                             (trim_cmd && *trim_cmd) ? trim_cmd : "(empty)",
                             err,
                             g_strerror(err));
            g_free(trim_cmd);
        }

        if (wire_log && rigctld_client_get_log_level() >= RIG_LOG_VERBOSE)
        {
            gchar *trim_cmd = rigctld_client_dup_trimmed(cmd);

            err = local.err ? local.err : EIO;
            rigctld_client_emit_logf(client, "gpredict:err",
                                     "request failed cmd=%s err=%d (%s)",
                                     (trim_cmd && *trim_cmd) ? trim_cmd : "(empty)",
                                     err,
                                     g_strerror(err));
            g_free(trim_cmd);
        }
        return FALSE;
    }

    if (wire_log && reply != NULL && reply_len > 0 && reply[0] != '\0')
        rigctld_client_forensic_lines(client, "gpredict:rx", reply);

    if (wire_log &&
        rigctld_client_get_log_level() >= RIG_LOG_VERBOSE &&
        reply != NULL && reply_len > 0 && reply[0] != '\0')
    {
        rigctld_client_emit_log_lines(client, "gpredict:rx", reply);
    }

    if (wire_log && local.saw_done &&
        (reply == NULL || g_strrstr(reply, "done") == NULL))
    {
        rigctld_client_forensic_line(client, "gpredict:rx", "done");
    }

    if (wire_log && local.saw_rprt &&
        (reply == NULL || g_strrstr(reply, "RPRT") == NULL))
    {
        sat_log_forensic(SAT_LOG_LEVEL_INFO,
                         "gpredict:rx: [%s] RPRT %d",
                         client->label ? client->label : "rig",
                         local.rprt_code);
    }

    if (wire_log && rigctld_client_get_log_level() >= RIG_LOG_VERBOSE)
    {
        if (local.saw_done &&
            (reply == NULL || g_strrstr(reply, "done") == NULL))
        {
            rigctld_client_emit_log_line(client, "gpredict:rx", "done");
        }

        if (local.saw_rprt &&
            (reply == NULL || g_strrstr(reply, "RPRT") == NULL))
        {
            rigctld_client_emit_logf(client, "gpredict:rx",
                                     "RPRT %d", local.rprt_code);
        }
    }

    if (wire_log &&
        rigctld_client_get_log_level() >= RIG_LOG_VERBOSE &&
        local.saw_rprt && local.rprt_code != 0)
    {
        gchar *trim_cmd = rigctld_client_dup_trimmed(cmd);

        rigctld_client_emit_logf(client, "gpredict:err",
                                 "request rejected cmd=%s rprt=%d",
                                 (trim_cmd && *trim_cmd) ? trim_cmd : "(empty)",
                                 local.rprt_code);
        g_free(trim_cmd);
    }

    return TRUE;
}

void rigctld_client_free(RigctldClient **client)
{
    if (client == NULL || *client == NULL)
        return;

    rigctld_client_close(*client);
    g_rec_mutex_lock(rigctld_client_meta_lock(*client));
    rigctld_client_caps_release(&(*client)->caps);
    g_free((*client)->state_reason);
    g_rec_mutex_unlock(rigctld_client_meta_lock(*client));
    g_free((*client)->label);
    g_rec_mutex_clear(&(*client)->meta_lock);
    g_free(*client);
    *client = NULL;
}

void rigctld_client_reset(RigctldClient *client)
{
    if (client == NULL)
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    rigctld_client_caps_clear(&client->caps);
    client->last_probe_us = 0;
    client->last_selected_vfo = VFO_NONE;
    rigctld_client_set_state(client, RIGCTLD_CLIENT_STOPPED, "reset");
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
}

gboolean rigctld_client_connect(RigctldClient *client,
                                const gchar *host,
                                gint port,
                                gint timeout_ms,
                                gchar **error_out)
{
    gboolean ok = FALSE;

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    rigctld_client_caps_clear(&client->caps);
    client->last_probe_us = 0;
    client->last_selected_vfo = VFO_NONE;

    rigctld_client_set_state(client, RIGCTLD_CLIENT_CONNECTING, "connect");
    ok = hamlib_transport_connect(client->transport, host, port,
                                  timeout_ms, error_out);
    if (!ok)
    {
        rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                 "connect failed");
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return FALSE;
    }

    rigctld_client_set_state(client, RIGCTLD_CLIENT_CONNECTING,
                             "connected");
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return TRUE;
}

gboolean rigctld_client_attach_fd(RigctldClient *client,
                                  gint fd,
                                  gchar **error_out)
{
    gboolean ok = FALSE;

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    rigctld_client_caps_clear(&client->caps);
    client->last_probe_us = 0;
    client->last_selected_vfo = VFO_NONE;

    rigctld_client_set_state(client, RIGCTLD_CLIENT_CONNECTING, "attach");
    ok = hamlib_transport_attach_fd(client->transport, fd, error_out);
    if (!ok)
    {
        rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                 "attach failed");
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return FALSE;
    }

    rigctld_client_set_state(client, RIGCTLD_CLIENT_CONNECTING, "attached");
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return TRUE;
}

void rigctld_client_close(RigctldClient *client)
{
    if (client == NULL)
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    hamlib_transport_close(client->transport);
    rigctld_client_set_state(client, RIGCTLD_CLIENT_STOPPED, "closed");
    client->last_selected_vfo = VFO_NONE;
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
}

rigctld_client_state_t rigctld_client_get_state(const RigctldClient *client)
{
    rigctld_client_state_t state = RIGCTLD_CLIENT_STOPPED;

    if (client == NULL)
        return RIGCTLD_CLIENT_STOPPED;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    state = client->state;
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return state;
}

void rigctld_client_get_status(const RigctldClient *client,
                               rigctld_client_state_t *state_out,
                               gchar *reason_out,
                               gsize reason_len)
{
    if (state_out)
        *state_out = RIGCTLD_CLIENT_STOPPED;
    if (reason_out && reason_len > 0)
        reason_out[0] = '\0';

    if (client == NULL)
        return;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    if (state_out)
        *state_out = client->state;
    if (reason_out && reason_len > 0)
        g_strlcpy(reason_out,
                  client->state_reason ? client->state_reason : "",
                  reason_len);
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
}

RigCaps *rigctld_client_get_caps_snapshot(const RigctldClient *client)
{
    RigCaps *caps = NULL;

    if (client == NULL)
        return NULL;

    caps = g_new0(RigCaps, 1);
    if (caps == NULL)
        return NULL;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    rigctld_client_caps_copy_snapshot(&client->caps, caps);
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return caps;
}

void rigctld_client_caps_snapshot_free(RigCaps *caps)
{
    if (caps == NULL)
        return;

    rigctld_client_caps_release(caps);
    g_free(caps);
}

HamlibTransport *rigctld_client_get_transport(RigctldClient *client)
{
    if (client == NULL)
        return NULL;
    return client->transport;
}

gboolean rigctld_client_probe(RigctldClient *client,
                              const radio_conf_t *conf,
                              gint timeout_ms)
{
    static const gchar *main_candidates[] =
        { "VFOA", "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_candidates[] =
        { "VFOB", "Sub", "SubA", "VFO_SUB", "TX", NULL };
    static const gchar *main_candidates_prefer[] =
        { "Main", "MainA", "VFO_MAIN", "RX", "VFOA", NULL };
    static const gchar *sub_candidates_prefer[] =
        { "Sub", "SubA", "VFO_SUB", "TX", "VFOB", NULL };
    static const gchar *main_candidates_strict[] =
        { "Main", "MainA", "VFO_MAIN", "RX", NULL };
    static const gchar *sub_candidates_strict[] =
        { "Sub", "SubA", "VFO_SUB", "TX", NULL };
    gchar dump_state[4096];
    gchar reply[256];
    gint64 freq = 0;
    gboolean dump_ok = FALSE;
    gboolean freq_ok = FALSE;
    gboolean vfo_select_ok = FALSE;
    gboolean vfo_opt_args_ok = FALSE;
    gboolean vfo_opt_set = FALSE;
    gboolean force_main_sub = FALSE;
    gboolean selection_only_main_sub_ok = FALSE;
    gboolean daemon_vfo_mode = FALSE;
    gint64 token_probe_freq = 0;
    gint select_attempts = 1;
    gulong select_settle_us = 0;
    GHashTable *vfo_selectable = NULL;
    HamlibResponseInfo info = { 0 };
    gint expected_model = rigctld_client_expected_model(conf);
    gint64 now_us = g_get_monotonic_time();

    if (client == NULL || client->transport == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    if (client->last_probe_us > 0 &&
        (now_us - client->last_probe_us) < 500000)
    {
        gboolean ready = (client->state == RIGCTLD_CLIENT_READY);

        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return ready;
    }

    client->last_probe_us = now_us;
    rigctld_client_set_state(client, RIGCTLD_CLIENT_PROBING, "probe start");

    rigctld_client_caps_clear(&client->caps);
    vfo_selectable = g_hash_table_new_full(g_str_hash, g_str_equal, g_free,
                                           NULL);
    if (!rigctld_client_request(client,
                                "\\dump_state\n",
                                HAMLIB_READ_MULTILINE_IDLE,
                                HAMLIB_TERM_RPRT_OR_DONE,
                                timeout_ms,
                                50,
                                1, RIGCTLD_PROBE_RETRY_DELAY_MS,
                                dump_state, sizeof(dump_state),
                                &info,
                                TRUE))
    {
        if (rigctld_client_get_log_level() >= RIG_LOG_VERBOSE)
            sat_log_log(SAT_LOG_LEVEL_DEBUG,
                        "rigctld probe dump_state failed err=%d rprt=%d done=%d",
                        info.err, info.saw_rprt ? 1 : 0, info.saw_done ? 1 : 0);
    }
    else
    {
        dump_ok = rigctld_dump_state_line1_ok(dump_state);
        if (!dump_ok)
        {
            if (rigctld_client_get_log_level() >= RIG_LOG_VERBOSE)
                sat_log_log(SAT_LOG_LEVEL_DEBUG,
                            "rigctld probe dump_state missing line1=1");
        }

        rigctld_client_parse_dump_state(&client->caps, dump_state);

        client->caps.signature =
            rigctld_client_build_signature(dump_state,
                                           client->caps.rig_model,
                                           client->caps.backend_version);
        rigctld_client_apply_quirks(&client->caps);

        if (expected_model > 0 && client->caps.rig_model > 0 &&
            client->caps.rig_model != expected_model)
        {
            rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                     "model mismatch expected=%d got=%d",
                                     expected_model, client->caps.rig_model);
            g_hash_table_destroy(vfo_selectable);
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return FALSE;
        }
    }

    if (rigctld_client_try_chk_vfo(client, &daemon_vfo_mode,
                                   timeout_ms, TRUE))
        client->caps.vfo_opt_enabled = daemon_vfo_mode;

    client->caps.prefer_main_sub_tokens =
        (conf != NULL && conf->radio_mode == RADIO_MODE_FULL_DUPLEX_MAIN_SUB);
    force_main_sub = ((client->caps.quirks & RIG_QUIRK_FORCE_MAIN_SUB) != 0);
    select_attempts = 1;
    select_settle_us = 0;

    if (client->caps.vfo_candidates->len == 0)
    {
        rigctld_client_add_vfo_candidate(&client->caps, "VFOA");
        rigctld_client_add_vfo_candidate(&client->caps, "VFOB");
        rigctld_client_add_vfo_candidate(&client->caps, "Main");
        rigctld_client_add_vfo_candidate(&client->caps, "MainA");
        rigctld_client_add_vfo_candidate(&client->caps, "Sub");
        rigctld_client_add_vfo_candidate(&client->caps, "SubA");
        rigctld_client_add_vfo_candidate(&client->caps, "RX");
        rigctld_client_add_vfo_candidate(&client->caps, "TX");
        rigctld_client_add_vfo_candidate(&client->caps, "currVFO");
    }

    freq_ok = rigctld_client_try_get_freq_retry(client,
                                                client->caps.vfo_opt_enabled
                                                    ? "f currVFO\n"
                                                    : "f\n",
                                                &freq, reply, sizeof(reply),
                                                timeout_ms, 0,
                                                TRUE);
    client->caps.has_get_freq = freq_ok;
    if (freq_ok)
        token_probe_freq = freq;

    if (client->caps.prefer_main_sub_tokens)
    {
        /* Probe shared Main/Sub rigs with a conservative pair handshake
           regardless of model identity. Some backends twitch during startup,
           and a full token sweep can perturb a radio that would otherwise be
           usable once both sides are selected cleanly. */
        for (gint round = 0; round < RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS; round++)
        {
            const gchar *main_token =
                rigctld_client_probe_select_token(client,
                                                  main_candidates,
                                                  vfo_selectable,
                                                  timeout_ms,
                                                  select_attempts,
                                                  select_settle_us,
                                                  TRUE,
                                                  FALSE,
                                                  TRUE);
            const gchar *sub_token = NULL;

            if (main_token != NULL && client->caps.default_vfo_token == NULL)
                client->caps.default_vfo_token = g_strdup(main_token);

            sub_token =
                rigctld_client_probe_select_token(client,
                                                  sub_candidates,
                                                  vfo_selectable,
                                                  timeout_ms,
                                                  select_attempts,
                                                  select_settle_us,
                                                  TRUE,
                                                  FALSE,
                                                  TRUE);

            if (main_token != NULL && sub_token != NULL)
                break;

            if ((round + 1) < RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS &&
                select_settle_us > 0)
            {
                g_usleep(select_settle_us);
            }
        }

        if (force_main_sub)
        {
            const gchar *main_token =
                rigctld_client_find_vfo_token_in_table(VFO_MAIN,
                                                       vfo_selectable);
            const gchar *sub_token =
                rigctld_client_find_vfo_token_in_table(VFO_SUB,
                                                       vfo_selectable);

            if (main_token == NULL || sub_token == NULL)
            {
                for (gint round = 0;
                     round < RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS &&
                     (main_token == NULL || sub_token == NULL);
                     round++)
                {
                    if (main_token == NULL)
                    {
                        main_token =
                            rigctld_client_probe_select_token(client,
                                                              main_candidates_strict,
                                                              vfo_selectable,
                                                              timeout_ms,
                                                              select_attempts,
                                                              select_settle_us,
                                                              TRUE,
                                                              FALSE,
                                                              TRUE);
                    }
                    if (sub_token == NULL)
                    {
                        sub_token =
                            rigctld_client_probe_select_token(client,
                                                              sub_candidates_strict,
                                                              vfo_selectable,
                                                              timeout_ms,
                                                              select_attempts,
                                                              select_settle_us,
                                                              TRUE,
                                                              FALSE,
                                                              TRUE);
                    }
                }

                if (main_token != NULL && sub_token != NULL)
                {
                    sat_log_log(SAT_LOG_LEVEL_INFO,
                                "rigctld probe: accepting selection-only Main/Sub fallback main=%s sub=%s",
                                main_token, sub_token);
                }
            }
        }

        if (client->caps.vfo_opt_enabled)
        {
            const gchar *main_token =
                rigctld_client_find_vfo_token_in_table(VFO_MAIN,
                                                       vfo_selectable);
            const gchar *sub_token =
                rigctld_client_find_vfo_token_in_table(VFO_SUB,
                                                       vfo_selectable);

            if ((main_token == NULL || sub_token == NULL) &&
                rigctld_client_try_set_ok(client,
                                          "\\set_vfo_opt 0\x0a",
                                          reply, sizeof(reply),
                                          timeout_ms,
                                          TRUE))
            {
                client->caps.vfo_opt_enabled = FALSE;
                sat_log_log(SAT_LOG_LEVEL_INFO,
                            "rigctld probe: retrying Main/Sub selection with vfo_opt disabled");

                for (gint round = 0;
                     round < RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS &&
                     (main_token == NULL || sub_token == NULL);
                     round++)
                {
                    if (main_token == NULL)
                    {
                        main_token =
                            rigctld_client_probe_select_token(client,
                                                              main_candidates,
                                                              vfo_selectable,
                                                              timeout_ms,
                                                              select_attempts,
                                                              select_settle_us,
                                                              TRUE,
                                                              FALSE,
                                                              TRUE);
                    }
                    if (sub_token == NULL)
                    {
                        sub_token =
                            rigctld_client_probe_select_token(client,
                                                              sub_candidates,
                                                              vfo_selectable,
                                                              timeout_ms,
                                                              select_attempts,
                                                              select_settle_us,
                                                              TRUE,
                                                              FALSE,
                                                              TRUE);
                    }
                }

                if (force_main_sub &&
                    (main_token == NULL || sub_token == NULL))
                {
                    for (gint round = 0;
                         round < RIGCTLD_MAIN_SUB_HANDSHAKE_ROUNDS &&
                         (main_token == NULL || sub_token == NULL);
                         round++)
                    {
                        if (main_token == NULL)
                        {
                            main_token =
                                rigctld_client_probe_select_token(
                                    client,
                                    main_candidates_strict,
                                    vfo_selectable,
                                    timeout_ms,
                                    select_attempts,
                                    select_settle_us,
                                    TRUE,
                                    FALSE,
                                    TRUE);
                        }
                        if (sub_token == NULL)
                        {
                            sub_token =
                                rigctld_client_probe_select_token(
                                    client,
                                    sub_candidates_strict,
                                    vfo_selectable,
                                    timeout_ms,
                                    select_attempts,
                                    select_settle_us,
                                    TRUE,
                                    FALSE,
                                    TRUE);
                        }
                    }
                }
            }
        }
    }
    else
    {
        for (guint i = 0; i < client->caps.vfo_candidates->len; i++)
        {
            const gchar *token =
                g_ptr_array_index(client->caps.vfo_candidates, i);

            if (!rigctld_client_try_select_vfo_retry(client, token,
                                                     timeout_ms,
                                                     select_attempts,
                                                     select_settle_us,
                                                     TRUE))
                continue;
            g_hash_table_replace(vfo_selectable, g_strdup(token),
                                 GINT_TO_POINTER(1));
            if (client->caps.default_vfo_token == NULL)
                client->caps.default_vfo_token = g_strdup(token);

            if (select_settle_us > 0)
                g_usleep(select_settle_us);

            if (rigctld_client_try_get_freq_retry(client, "f\n",
                                                  &freq, reply, sizeof(reply),
                                                  timeout_ms, 0,
                                                  TRUE))
            {
                vfo_select_ok = TRUE;
                g_hash_table_replace(client->caps.vfo_working,
                                     g_strdup(token),
                                     GINT_TO_POINTER(1));
            }
        }
    }

    if (client->caps.prefer_main_sub_tokens)
    {
        const gchar *main_working =
            rigctld_client_find_vfo_token_in_table(VFO_MAIN,
                                                   client->caps.vfo_working);
        const gchar *sub_working =
            rigctld_client_find_vfo_token_in_table(VFO_SUB,
                                                   client->caps.vfo_working);
        const gchar *main_token = main_working;
        const gchar *sub_token = sub_working;

        if (main_token == NULL)
            main_token = rigctld_client_find_vfo_token_in_table(VFO_MAIN,
                                                                vfo_selectable);
        if (sub_token == NULL)
            sub_token = rigctld_client_find_vfo_token_in_table(VFO_SUB,
                                                               vfo_selectable);

        g_free(client->caps.vfo_token_main);
        client->caps.vfo_token_main =
            main_token ? g_strdup(main_token) : NULL;
        g_free(client->caps.vfo_token_sub);
        client->caps.vfo_token_sub =
            sub_token ? g_strdup(sub_token) : NULL;

        if (main_token != NULL && sub_token != NULL)
        {
            if (client->caps.default_vfo_token == NULL)
                client->caps.default_vfo_token = g_strdup(main_token);

            vfo_select_ok = (main_working != NULL && sub_working != NULL);
            selection_only_main_sub_ok =
                (!vfo_select_ok &&
                 main_token != NULL && sub_token != NULL);
        }
        else
        {
            /* Shared Main/Sub control is only usable when both sides resolve
               to a real token. */
            vfo_select_ok = FALSE;
            selection_only_main_sub_ok = FALSE;
        }
    }

    if ((client->caps.has_set_vfo_opt ||
         (conf != NULL && conf->vfo_opt) ||
         (client->caps.prefer_main_sub_tokens && !vfo_select_ok)) &&
        !(client->caps.prefer_main_sub_tokens && vfo_select_ok))
    {
        vfo_opt_set = rigctld_client_try_set_ok(client,
                                                "\\set_vfo_opt 1\x0a",
                                                reply, sizeof(reply),
                                                timeout_ms,
                                                TRUE);
        if (vfo_opt_set)
        {
            const gchar * const *main_vfo_opt_candidates = NULL;
            const gchar * const *sub_vfo_opt_candidates = NULL;
            gboolean allow_unlisted =
                (client->caps.quirks & RIG_QUIRK_FORCE_MAIN_SUB) != 0;

            client->caps.has_set_vfo_opt = TRUE;
            client->caps.vfo_opt_enabled = TRUE;

            if (client->caps.prefer_main_sub_tokens)
            {
                const gchar *main_token = NULL;
                const gchar *sub_token = NULL;

                if (client->caps.quirks & RIG_QUIRK_FORCE_MAIN_SUB)
                {
                    main_vfo_opt_candidates = main_candidates_strict;
                    sub_vfo_opt_candidates = sub_candidates_strict;
                }
                else if (client->caps.prefer_main_sub_tokens)
                {
                    main_vfo_opt_candidates = main_candidates_prefer;
                    sub_vfo_opt_candidates = sub_candidates_prefer;
                }
                else
                {
                    main_vfo_opt_candidates = main_candidates;
                    sub_vfo_opt_candidates = sub_candidates;
                }

                main_token = rigctld_client_probe_tokenized_vfo_token(
                    client, main_vfo_opt_candidates,
                    allow_unlisted,
                    &token_probe_freq,
                    timeout_ms,
                    TRUE);
                sub_token = rigctld_client_probe_tokenized_vfo_token(
                    client, sub_vfo_opt_candidates,
                    allow_unlisted,
                    &token_probe_freq,
                    timeout_ms,
                    TRUE);

                if (main_token != NULL && sub_token != NULL)
                {
                    g_free(client->caps.vfo_token_main);
                    client->caps.vfo_token_main = g_strdup(main_token);
                    g_free(client->caps.vfo_token_sub);
                    client->caps.vfo_token_sub = g_strdup(sub_token);
                    vfo_opt_args_ok = TRUE;
                    g_free(client->caps.default_vfo_token);
                    client->caps.default_vfo_token = g_strdup(main_token);
                }
            }
            else
            {
                for (guint i = 0; i < client->caps.vfo_candidates->len; i++)
                {
                    const gchar *token =
                        g_ptr_array_index(client->caps.vfo_candidates, i);

                    if (!rigctld_client_probe_tokenized_freq_token(client,
                                                                   token,
                                                                   &token_probe_freq,
                                                                   timeout_ms,
                                                                   TRUE))
                        continue;

                    g_free(client->caps.default_vfo_token);
                    client->caps.default_vfo_token = g_strdup(token);
                    vfo_opt_args_ok = TRUE;
                    break;
                }
            }

            if (!vfo_opt_args_ok)
            {
                client->caps.vfo_opt_unsafe = TRUE;
                rigctld_client_try_set_ok(client, "\\set_vfo_opt 0\x0a",
                                          reply, sizeof(reply),
                                          timeout_ms,
                                          TRUE);
                client->caps.vfo_opt_enabled = FALSE;
            }
        }
    }

    if (conf != NULL &&
        conf->radio_mode == RADIO_MODE_FULL_DUPLEX_MAIN_SUB &&
        client->caps.vfo_token_main != NULL &&
        client->caps.vfo_token_sub != NULL)
    {
        vfo_select_ok = TRUE;
        selection_only_main_sub_ok = TRUE;
        /* Shared Main/Sub rigs should stay on the simpler V + F path once
           both sides resolve to selectable tokens. Tokenized F <vfo> <freq>
           support is not reliable enough here. */
        vfo_opt_args_ok = FALSE;
        if (!g_hash_table_contains(client->caps.vfo_working,
                                   client->caps.vfo_token_main))
        {
            g_hash_table_replace(client->caps.vfo_working,
                                 g_strdup(client->caps.vfo_token_main),
                                 GINT_TO_POINTER(1));
        }
        if (!g_hash_table_contains(client->caps.vfo_working,
                                   client->caps.vfo_token_sub))
        {
            g_hash_table_replace(client->caps.vfo_working,
                                 g_strdup(client->caps.vfo_token_sub),
                                 GINT_TO_POINTER(1));
        }
        if (client->caps.default_vfo_token == NULL)
            client->caps.default_vfo_token =
                g_strdup(client->caps.vfo_token_main);

        sat_log_log(SAT_LOG_LEVEL_INFO,
                    "rigctld probe: falling back to selection-only Main/Sub strategy main=%s sub=%s",
                    client->caps.vfo_token_main,
                    client->caps.vfo_token_sub);
    }

    if (vfo_opt_args_ok)
    {
        client->caps.strategy = RIG_STRATEGY_VFO_OPT_ARGS;
        if (client->caps.default_vfo_token == NULL)
            client->caps.default_vfo_token = g_strdup("currVFO");
    }
    else if (vfo_select_ok)
    {
        client->caps.strategy = RIG_STRATEGY_SELECT_VFO;
    }
    else if (freq_ok)
    {
        client->caps.strategy = RIG_STRATEGY_PLAIN_FREQ;
        if (client->caps.vfo_opt_enabled)
        {
            rigctld_client_try_set_ok(client, "\\set_vfo_opt 0\x0a",
                                      reply, sizeof(reply), timeout_ms,
                                      TRUE);
            client->caps.vfo_opt_enabled = FALSE;
        }
    }
    else if (dump_ok)
    {
        client->caps.strategy = RIG_STRATEGY_PLAIN_FREQ;
    }
    else
    {
        rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                 "no usable control strategy");
        g_hash_table_destroy(vfo_selectable);
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return FALSE;
    }

    if (conf != NULL &&
        conf->radio_mode == RADIO_MODE_FULL_DUPLEX_MAIN_SUB &&
        client->caps.strategy != RIG_STRATEGY_SELECT_VFO &&
        client->caps.strategy != RIG_STRATEGY_VFO_OPT_ARGS)
    {
        rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                 "shared Main/Sub requires explicit VFO control");
        g_hash_table_destroy(vfo_selectable);
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return FALSE;
    }

    if (!dump_ok && !freq_ok && !vfo_select_ok && !vfo_opt_args_ok)
    {
        rigctld_client_set_state(client, RIGCTLD_CLIENT_DEGRADED,
                                 "probe failed");
        g_hash_table_destroy(vfo_selectable);
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return FALSE;
    }

    rigctld_client_set_state(client, RIGCTLD_CLIENT_READY,
                             "strategy=%d", client->caps.strategy);
    g_hash_table_destroy(vfo_selectable);
    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return TRUE;
}

gboolean rigctld_client_get_freq(RigctldClient *client,
                                 vfo_t vfo,
                                 gint64 *freq_out)
{
    gchar cmd[96];
    gchar reply[256];
    RigCaps *caps = NULL;

    if (freq_out)
        *freq_out = 0;

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    caps = &client->caps;

    if (caps->strategy == RIG_STRATEGY_VFO_OPT_ARGS)
    {
        if (caps->has_tokenized_get_freq)
        {
            const gchar *token = NULL;
            token = rigctld_client_vfo_token(client, vfo);
            g_snprintf(cmd, sizeof(cmd), "f %s\x0a", token);
            {
                gboolean ok = rigctld_client_try_get_freq(client, cmd,
                                                          freq_out, reply,
                                                          sizeof(reply), 500,
                                                          FALSE);
                g_rec_mutex_unlock(rigctld_client_meta_lock(client));
                return ok;
            }
        }
    }

    if (caps->strategy == RIG_STRATEGY_SELECT_VFO)
    {
        if (!rigctld_client_ensure_vfo(client, vfo))
        {
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return FALSE;
        }
        if (rigctld_client_caps_fragile_main_sub(caps))
            g_usleep(RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US);
    }

    g_snprintf(cmd, sizeof(cmd), "%s",
               caps->vfo_opt_enabled ? "f currVFO\x0a" : "f\x0a");
    {
        gboolean ok = rigctld_client_try_get_freq(client, cmd,
                                                  freq_out, reply,
                                                  sizeof(reply), 500,
                                                  FALSE);
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return ok;
    }
}

gboolean rigctld_client_ensure_vfo(RigctldClient *client,
                                   vfo_t vfo)
{
    RigCaps *caps = NULL;
    const gchar *token = NULL;
    gboolean ok = FALSE;
    gboolean force_reselect = FALSE;
    gboolean fragile_main_sub = FALSE;

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    caps = &client->caps;
    if (caps->strategy != RIG_STRATEGY_SELECT_VFO)
    {
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return TRUE;
    }

    if (vfo != VFO_MAIN && vfo != VFO_SUB)
    {
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return TRUE;
    }

    force_reselect = (caps->strategy == RIG_STRATEGY_SELECT_VFO &&
                      caps->prefer_main_sub_tokens &&
                      (caps->quirks & RIG_QUIRK_FORCE_MAIN_SUB) != 0);
    fragile_main_sub = rigctld_client_caps_fragile_main_sub(caps);

    if (!force_reselect && client->last_selected_vfo == vfo)
    {
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return TRUE;
    }

    token = rigctld_client_vfo_token(client, vfo);
    ok = rigctld_client_try_select_vfo_retry(
        client, token, 500,
        fragile_main_sub ? RIGCTLD_MAIN_SUB_FRAGILE_SELECT_ATTEMPTS : 1,
        fragile_main_sub ? RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US : 0,
        TRUE);
    if (ok)
        client->last_selected_vfo = vfo;

    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return ok;
}

gboolean rigctld_client_set_freq(RigctldClient *client,
                                 vfo_t vfo,
                                 gint64 freq_hz)
{
    gchar cmd[96];
    gchar reply[128];
    const gchar *token = NULL;
    RigCaps *caps = NULL;
    gboolean ok = FALSE;
    gboolean fragile_main_sub = FALSE;

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    caps = &client->caps;
    fragile_main_sub = rigctld_client_caps_fragile_main_sub(caps);

    if (caps->strategy == RIG_STRATEGY_VFO_OPT_ARGS)
    {
        gboolean can_select = (vfo == VFO_MAIN || vfo == VFO_SUB);

        token = rigctld_client_vfo_token(client, vfo);
        if (token != NULL && *token != '\0')
        {
            g_snprintf(cmd, sizeof(cmd), "F %s %" G_GINT64_FORMAT "\x0a",
                       token, freq_hz);
            ok = rigctld_client_try_set_ok(client, cmd,
                                           reply, sizeof(reply), 500,
                                           TRUE);
            if (ok)
                caps->has_tokenized_set_freq = TRUE;
            if (ok || !can_select)
            {
                g_rec_mutex_unlock(rigctld_client_meta_lock(client));
                return ok;
            }
        }

        if (can_select)
        {
            if (!rigctld_client_ensure_vfo(client, vfo))
            {
                g_rec_mutex_unlock(rigctld_client_meta_lock(client));
                return FALSE;
            }
            if (fragile_main_sub)
                g_usleep(RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US);
        }

        g_snprintf(cmd, sizeof(cmd),
                   caps->vfo_opt_enabled ? "F currVFO %" G_GINT64_FORMAT "\x0a"
                                         : "F %" G_GINT64_FORMAT "\x0a",
                   freq_hz);
        ok = rigctld_client_try_set_ok(client, cmd,
                                       reply, sizeof(reply), 500,
                                       TRUE);
        if (ok)
            caps->has_set_freq = TRUE;
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return ok;
    }

    if (caps->strategy == RIG_STRATEGY_SELECT_VFO)
    {
        gboolean can_select = (vfo == VFO_MAIN || vfo == VFO_SUB);

        if (can_select && !rigctld_client_ensure_vfo(client, vfo))
        {
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return FALSE;
        }
        if (can_select && fragile_main_sub)
            g_usleep(RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US);

        g_snprintf(cmd, sizeof(cmd),
                   caps->vfo_opt_enabled ? "F currVFO %" G_GINT64_FORMAT "\x0a"
                                         : "F %" G_GINT64_FORMAT "\x0a",
                   freq_hz);
        ok = rigctld_client_try_set_ok(client, cmd,
                                       reply, sizeof(reply), 500,
                                       TRUE);
        if (ok || !can_select)
        {
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return ok;
        }

        token = rigctld_client_vfo_token(client, vfo);
        if (!rigctld_client_try_select_vfo_retry(
                client, token, 500,
                fragile_main_sub ? RIGCTLD_MAIN_SUB_FRAGILE_SELECT_ATTEMPTS : 1,
                fragile_main_sub ? RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US : 0,
                TRUE))
        {
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return FALSE;
        }
        client->last_selected_vfo = vfo;
        if (fragile_main_sub)
            g_usleep(RIGCTLD_MAIN_SUB_FRAGILE_SELECT_SETTLE_US);
        {
            gboolean retry_ok = rigctld_client_try_set_ok(client, cmd,
                                                          reply,
                                                          sizeof(reply), 500,
                                                          TRUE);
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return retry_ok;
        }
    }

    g_snprintf(cmd, sizeof(cmd), "F %" G_GINT64_FORMAT "\x0a", freq_hz);
    {
        gboolean ok = rigctld_client_try_set_ok(client, cmd,
                                                reply, sizeof(reply), 500,
                                                TRUE);
        g_rec_mutex_unlock(rigctld_client_meta_lock(client));
        return ok;
    }
}

gboolean rigctld_client_set_vfo(RigctldClient *client,
                                const gchar *token)
{
    gchar cmd[96];
    gchar reply[128];

    if (client == NULL || token == NULL || *token == '\0')
        return FALSE;

    g_snprintf(cmd, sizeof(cmd), "V %s\x0a", token);
    return rigctld_client_try_set_ok(client, cmd,
                                     reply, sizeof(reply), 500,
                                     TRUE);
}

gboolean rigctld_client_set_vfo_opt(RigctldClient *client,
                                    gboolean enable)
{
    gchar reply[128];

    if (client == NULL)
        return FALSE;

    g_rec_mutex_lock(rigctld_client_meta_lock(client));
    if (enable)
    {
        if (rigctld_client_try_set_ok(client, "\\set_vfo_opt 1\x0a",
                                      reply, sizeof(reply), 500,
                                      TRUE))
        {
            client->caps.vfo_opt_enabled = TRUE;
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return TRUE;
        }
    }
    else
    {
        if (rigctld_client_try_set_ok(client, "\\set_vfo_opt 0\x0a",
                                      reply, sizeof(reply), 500,
                                      TRUE))
        {
            client->caps.vfo_opt_enabled = FALSE;
            g_rec_mutex_unlock(rigctld_client_meta_lock(client));
            return TRUE;
        }
    }

    g_rec_mutex_unlock(rigctld_client_meta_lock(client));
    return FALSE;
}

gboolean rigctld_client_request_raw(RigctldClient *client,
                                    const gchar *cmd,
                                    gchar *out,
                                    gsize out_len,
                                    HamlibResponseInfo *info)
{
    hamlib_read_mode_t mode = HAMLIB_READ_MULTILINE_RPRT;
    HamlibResponseInfo local = { 0 };
    gboolean ok = FALSE;
    const gchar *send_cmd = NULL;
    gchar *tmp_cmd = NULL;
    gsize cmd_len = 0;
    gint request_timeout_ms = 1000;

    if (info)
        memset(info, 0, sizeof(*info));

    if (client == NULL || cmd == NULL)
        return FALSE;

    cmd_len = strlen(cmd);
    if (cmd_len > 0 && cmd[cmd_len - 1] != '\n')
    {
        tmp_cmd = g_strdup_printf("%s\n", cmd);
        send_cmd = tmp_cmd;
    }
    else
    {
        send_cmd = cmd;
    }

    if (g_str_has_prefix(send_cmd, "\\dump_state"))
        mode = HAMLIB_READ_MULTILINE_IDLE;
    else if (g_str_has_prefix(send_cmd, "F ") ||
             g_str_has_prefix(send_cmd, "I "))
        request_timeout_ms = 3000;

    ok = rigctld_client_request(client,
                                send_cmd,
                                mode,
                                HAMLIB_TERM_RPRT,
                                request_timeout_ms,
                                RIGCTLD_REPLY_IDLE_TIMEOUT_MS,
                                0, 0,
                                out, out_len,
                                &local,
                                FALSE);
    g_free(tmp_cmd);
    if (info)
        *info = local;
    if (!ok)
        return FALSE;

    if (out && out_len > 0 && local.saw_rprt)
    {
        gchar rprt[32];
        g_snprintf(rprt, sizeof(rprt), "RPRT %d\n", local.rprt_code);
        g_strlcat(out, rprt, out_len);
    }

    return TRUE;
}

gint64 rigctld_client_last_rtt_us(const RigctldClient *client)
{
    if (client == NULL || client->transport == NULL)
        return 0;
    return hamlib_transport_last_rtt_us(client->transport);
}
