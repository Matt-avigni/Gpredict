/*
    Gpredict: Real-time satellite tracking and orbit prediction program

    Copyright (C)  2001-2015  Alexandru Csete.

    Authors: Alexandru Csete <oz9aec@gmail.com>

    Comments, questions and bugreports should be submitted via
    http://sourceforge.net/projects/gpredict/
    More details can be found at the project home page:

            http://gpredict.oz9aec.net/
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License
    along with this program; if not, visit http://www.fsf.org/
 

*/
#ifndef RADIO_CONF_H
#define RADIO_CONF_H 1

#include <glib.h>


/** \brief Radio types. */
typedef enum {
    RIG_TYPE_RX = 0,            /*!< Rig can only be used as receiver */
    RIG_TYPE_TX,                /*!< Rig can only be used as transmitter */
    RIG_TYPE_TRX,               /*!< Rig can be used as RX/TX (half-duplex only) */
    RIG_TYPE_DUPLEX,            /*!< Rig is a full duplex radio, e.g. IC910 */
    RIG_TYPE_TOGGLE_AUTO,       /*!< Special mode for FT-817, 857 and 897 using auto T/R switch */
    RIG_TYPE_TOGGLE_MAN         /*!< Special mode for FT-817, 857 and 897 using manual T/R switch */
} rig_type_t;

typedef enum {
    PTT_TYPE_NONE = 0,          /*!< Don't read PTT */
    PTT_TYPE_CAT,               /*!< Read PTT using get_ptt CAT command */
    PTT_TYPE_DCD                /*!< Read PTT using get_dcd */
} ptt_type_t;

typedef enum {
    RADIO_MODEL_OTHER = 0,
    RADIO_MODEL_IC9700,
    RADIO_MODEL_IC705,
    RADIO_MODEL_IC905
} radio_model_t;

typedef enum {
    RADIO_MODE_SIMPLEX = 0,
    RADIO_MODE_SPLIT,
    RADIO_MODE_FULL_DUPLEX_MAIN_SUB
} radio_mode_t;

typedef enum {
    RIGCTLD_CONN_SERIAL = 0,
    RIGCTLD_CONN_TCP
} rigctld_conn_t;

typedef enum {
    RIG_LOG_QUIET = 0,
    RIG_LOG_VERBOSE,
    RIG_LOG_TRACE
} rig_log_level_t;

typedef enum {
    VFO_NONE = 0,
    VFO_A,
    VFO_B,
    VFO_MAIN,
    VFO_SUB
} vfo_t;

/** \brief Radio configuration. */
typedef struct {
    gchar          *name;       /*!< Configuration file name, without .rig. */
    gchar          *host;       /*!< hostname or IP */
    gint            port;       /*!< port number */
    gint            cycle;      /*!< cycle period in msec */
    gdouble         lo;         /*!< local oscillator freq in Hz (using double for
                                   compatibility with rest of code). Downlink. */
    gdouble         loup;       /*!< local oscillator freq in Hz for uplink. */
    rig_type_t      type;       /*!< Radio type */
    radio_model_t   radio_model; /*!< Radio model selection */
    radio_mode_t    radio_mode;  /*!< Radio mode selection */
    ptt_type_t      ptt;        /*!< PTT type (needed for RX, TX, and TRX) */
    vfo_t           downlink_vfo;    /*!< Downlink VFO for full-duplex radios */
    vfo_t           uplink_vfo;      /*!< Uplink VFO for full-duplex radios */

    gboolean        signal_aos; /*!< Send AOS notification to RIG */
    gboolean        signal_los; /*!< Send LOS notification to RIG */

    gint            vfo_opt;    /*!< Keep track of vfo_opt being enabled in rigctld */

    gboolean        supports_rit_xit; /*!< Radio supports Doppler via RIT/XIT offsets */
    gboolean        supports_full_duplex; /*!< Radio supports full duplex operation */
    gboolean        supports_dual_vfo_sat; /*!< Radio supports dual VFO satellite mode */

    gboolean        rigctld_autostart; /*!< Auto-start rigctld on connection failure */
    gboolean        rigctld_auto_power_on; /*!< Auto power-on rig during rigctld start */
    gchar          *rigctld_path; /*!< rigctld binary path (empty uses PATH) */
    gint            rigctld_model; /*!< rigctld model number */
    rigctld_conn_t  rigctld_conn; /*!< Connection type for rigctld */
    gchar          *rigctld_device; /*!< rigctld device path or host:port */
    gint            rigctld_baud; /*!< rigctld baud rate */
    gchar          *rigctld_civaddr; /*!< Optional CI-V address string */
    gchar          *rigctld_extra_args; /*!< Optional extra rigctld args */
    gchar          *rigctld_autodetect_match; /*!< Optional substring allowlist for rig auto-detect */
    rig_log_level_t rig_log_level; /*!< Rig logging verbosity */
} radio_conf_t;

typedef struct {
    const gchar    *host;
    gint            port;
    rigctld_conn_t  conn;
    gint            baud;
    const gchar    *civaddr;
} rigctld_preset_defaults_t;


gboolean        radio_conf_read(radio_conf_t * conf);
void            radio_conf_save(radio_conf_t * conf);
void            radio_conf_refresh_runtime_flags(radio_conf_t *conf);
gboolean        radio_mode_allowed_for_model(radio_model_t model,
                                             radio_mode_t mode);
gchar          *radio_mode_allowed_string(radio_model_t model);
const gchar    *radio_model_to_string(radio_model_t model);
const gchar    *radio_mode_to_string(radio_mode_t mode);
gint            radio_model_to_hamlib_model(radio_model_t model);
gboolean        radio_model_get_rigctld_defaults(radio_model_t model,
                                                 rigctld_preset_defaults_t *out);


#endif
